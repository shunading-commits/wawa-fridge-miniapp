App({
  onLaunch() {
    if (wx.cloud) wx.cloud.init({ traceUser: true })
  },
  globalData: { appName: '呱呱食仓' }
})
