const Store = require('../../utils/store')
const Recommend = require('../../utils/recipe-recommend')
const Auth = require('../../utils/auth')

const recipes = {
  早餐: [
    { name: '奶香蒸蛋', art: '/assets/dishes/milk-steamed-egg.jpg', cal: 310, stars: '★☆☆☆☆', ingredients: [['鸡蛋', 2, '个'], ['牛奶', 0.5, '盒']], steps: ['鸡蛋打散并加入牛奶。', '过滤蛋液。', '蒸12分钟并焖2分钟。'] },
    { name: '番茄鸡蛋早餐碗', art: '/assets/dishes/tomato-egg-bowl.jpg', cal: 380, stars: '★★☆☆☆', ingredients: [['番茄', 1, '个'], ['鸡蛋', 2, '个']], steps: ['番茄切块。', '炒鸡蛋。', '加入番茄翻炒。'] },
    { name: '生菜鸡蛋粥', art: '/assets/dishes/lettuce-egg-congee.jpg', cal: 420, stars: '★★☆☆☆', ingredients: [['剩饭', 1, '碗'], ['生菜', 0.5, '棵'], ['鸡蛋', 1, '个']], steps: ['剩饭加水煮开。', '加入生菜。', '淋入蛋液。'] }
  ],
  午餐: [
    { name: '生菜鸡蛋炒饭', art: '/assets/dishes/lettuce-egg-rice.jpg', cal: 520, stars: '★★☆☆☆', ingredients: [['剩饭', 1, '碗'], ['生菜', 0.5, '棵'], ['鸡蛋', 1, '个']], steps: ['生菜切碎。', '鸡蛋炒熟后加入剩饭。', '加入生菜快速炒匀。'] },
    { name: '奶香番茄蒸蛋', art: '/assets/dishes/tomato-milk-egg.jpg', cal: 350, stars: '★★☆☆☆', ingredients: [['番茄', 1, '个'], ['鸡蛋', 2, '个'], ['牛奶', 0.5, '盒']], steps: ['混合鸡蛋和牛奶。', '加入番茄丁。', '蒸12分钟。'] },
    { name: '生菜午餐肉汤', art: '/assets/dishes/lettuce-luncheon-soup.jpg', cal: 460, stars: '★★★☆☆', ingredients: [['生菜', 0.5, '棵'], ['午餐肉', 0.5, '盒']], steps: ['午餐肉切片。', '加水煮开。', '加入生菜。'] }
  ],
  晚餐: [
    { name: '番茄生菜汤饭', art: '/assets/dishes/tomato-lettuce-rice.jpg', cal: 490, stars: '★★☆☆☆', ingredients: [['番茄', 1, '个'], ['生菜', 0.5, '棵'], ['剩饭', 1, '碗']], steps: ['番茄煮出汤汁。', '加入剩饭。', '加入生菜。'] },
    { name: '午餐肉鸡蛋煎', art: '/assets/dishes/luncheon-egg-pancake.jpg', cal: 570, stars: '★★★☆☆', ingredients: [['午餐肉', 0.5, '盒'], ['鸡蛋', 2, '个']], steps: ['午餐肉切丁。', '混合蛋液。', '小火煎熟。'] },
    { name: '奶香番茄浓汤', art: '/assets/dishes/creamy-tomato-soup.jpg', cal: 330, stars: '★★★☆☆', ingredients: [['番茄', 2, '个'], ['牛奶', 0.5, '盒']], steps: ['番茄炒软。', '加水煮开。', '加入牛奶。'] }
  ]
}

const clone = value => JSON.parse(JSON.stringify(value))
const catalog = Object.keys(recipes).reduce((all, meal) => all.concat(recipes[meal]), [])
const breakfastNames = ['奶香蒸蛋', '番茄鸡蛋早餐碗', '生菜鸡蛋粥', '奶香番茄蒸蛋', '午餐肉鸡蛋煎', '奶香番茄浓汤']
const foodArt = {
  番茄: '/assets/food-exact/tomato.png', 鸡蛋: '/assets/food-exact/egg.png',
  剩饭: '/assets/food-exact/rice.png', 生菜: '/assets/food-exact/lettuce.png',
  牛奶: '/assets/food-exact/milk.png', 午餐肉: '/assets/food-exact/luncheon.png'
}

function candidates(meal) {
  return meal === '早餐' ? catalog.filter(item => breakfastNames.includes(item.name)) : catalog
}

function decorate(recipe, favorites) {
  return {
    ...recipe,
    favorite: favorites.includes(recipe.name),
    steps: recipe.steps.map((text, index) => ({
      text,
      image: index === recipe.steps.length - 1 ? recipe.art : foodArt[recipe.ingredients[index % recipe.ingredients.length][0]] || ''
    }))
  }
}

Page({
  data: {
    meal: '午餐',
    shown: recipes.午餐,
    selected: null,
    factors: [0.5, 1, 1.5, 2],
    factor: 1,
    scaled: [],
    calories: 0,
    stepsVisible: false,
    cookChoices: [],
    adjusting: false,
    adjustRows: []
  },

  onShow() {
    if (!Auth.guard()) return
    if (this.getTabBar && this.getTabBar()) this.getTabBar().setData({ selected: 1 })
    this.state = Store.get()
    const hour = new Date().getHours()
    const meal = hour < 11 ? '早餐' : hour < 17 ? '午餐' : '晚餐'
    this.refreshRecommendations(this.data.selected ? this.data.meal : meal, true)
    if (this.data.selected) this.scale()
    Store.refresh().then(() => { this.state = Store.get(); this.refreshRecommendations(this.data.meal, true); if (this.data.selected) this.scale() }).catch(() => {})
  },

  refreshRecommendations(meal, reset) {
    if (reset) this.recipeOffset = 0
    this.rankedRecipes = Recommend.rank(candidates(meal), this.state.inventory, this.state.reminderDays || 3)
      .map(item => decorate(item, this.state.favorites || []))
    this.setData({ meal, shown: Recommend.batch(this.rankedRecipes, this.recipeOffset || 0, 3) })
  },

  changeMeal(e) {
    const meal = e.currentTarget.dataset.meal
    this.setData({ selected: null, stepsVisible: false, adjusting: false })
    this.refreshRecommendations(meal, true)
  },

  swap() {
    if (!this.rankedRecipes || !this.rankedRecipes.length) return
    this.recipeOffset = ((this.recipeOffset || 0) + 3) % this.rankedRecipes.length
    this.setData({ shown: Recommend.batch(this.rankedRecipes, this.recipeOffset, 3) })
  },

  openRecipe(e) {
    this.setData({ selected: this.data.shown[Number(e.currentTarget.dataset.index)], factor: 1, stepsVisible: false, adjusting: false })
    this.scale()
  },

  back() {
    this.setData({ selected: null, stepsVisible: false, adjusting: false })
  },

  changeFactor(e) {
    this.setData({ factor: Number(e.currentTarget.dataset.factor), stepsVisible: false })
    this.scale()
  },

  scale() {
    const factor = this.data.factor
    const scaled = this.data.selected.ingredients.map(([name, quantity, unit]) => {
      let need = Math.round(quantity * factor * 2) / 2
      if (name === '鸡蛋') need = Math.max(1, Math.round(need))
      const inventory = this.state.inventory.find(item => item.name === name)
      const home = inventory ? Store.total(inventory) : 0
      return { name, need, unit, home, short: Math.max(0, need - home) }
    })
    this.setData({ scaled, calories: Math.round(this.data.selected.cal * factor), cookChoices: [] })
  },

  favorite(e) {
    const recipe = this.data.shown[Number(e.currentTarget.dataset.index)]
    recipe.favorite = !recipe.favorite
    if (recipe.favorite && !this.state.favorites.includes(recipe.name)) this.state.favorites.push(recipe.name)
    if (!recipe.favorite) this.state.favorites = this.state.favorites.filter(name => name !== recipe.name)
    Store.set(this.state)
    this.setData({ shown: this.data.shown })
  },

  addMissing() {
    const missing = this.data.scaled.filter(item => item.short > 0)
    if (!missing.length) return wx.showToast({ title: '食材充足' })
    const itemList = this.state.sharedListId ? ['加入个人清单', '加入共享清单'] : ['加入个人清单']
    wx.showActionSheet({
      itemList,
      success: ({ tapIndex }) => {
        const listName = tapIndex === 0 ? 'personal' : this.state.sharedListId ? 'shared' : ''
        if (!listName) return
        missing.forEach(item => this.state.lists[listName].push({ id: `m${Date.now()}${item.name}`, name: item.name, qty: `${item.short}${item.unit}`, by: '我', done: false }))
        Store.commit(this.state, listName === 'shared' ? { type: 'addListItems', data: { items: missing.map(item => ({ id: `m${Date.now()}${item.name}`, name: item.name, qty: `${item.short}${item.unit}`, by: '我', done: false })) } } : null)
        wx.showToast({ title: listName === 'personal' ? '已加入个人清单' : '已加入共享清单' })
      }
    })
  },

  showSteps() {
    const visible = !this.data.stepsVisible
    this.setData({ stepsVisible: visible, cookChoices: visible ? this.buildCookChoices() : [] })
  },

  buildCookChoices() {
    return this.data.scaled.map(item => {
      const inventory = this.state.inventory.find(food => food.name === item.name)
      if (!inventory || !inventory.batches.length) {
        return { name: item.name, need: item.need, unit: item.unit, foodId: '', batchIds: [''], options: ['无库存'], selectedIndex: 0 }
      }
      return {
        name: item.name,
        need: item.need,
        unit: item.unit,
        foodId: inventory.id,
        batchIds: inventory.batches.map(batch => batch.id),
        options: inventory.batches.map(batch => `${batch.expiry} · 剩余${batch.qty}${item.unit}`),
        selectedIndex: 0
      }
    })
  },

  changeCookBatch(e) {
    const index = Number(e.currentTarget.dataset.index)
    const cookChoices = this.data.cookChoices.slice()
    cookChoices[index].selectedIndex = Number(e.detail.value)
    this.setData({ cookChoices })
  },

  applyRows(state, rows) {
    const depleted = []
    const shortages = []
    rows.forEach(row => {
      const food = state.inventory.find(item => item.id === row.foodId)
      if (!food) {
        shortages.push(row.name)
        return
      }
      const requested = Math.max(0, Number(row.actual) || 0)
      const used = Store.deduct(food, requested)
      if (used < requested) shortages.push(row.name)
      if (Store.total(food) === 0) depleted.push({ name: food.name, unit: food.unit })
    })
    state.inventory = state.inventory.filter(food => Store.total(food) > 0)
    return { depleted, shortages: [...new Set(shortages)] }
  },

  finish() {
    this.beforeCook = clone(this.state)
    const adjustRows = this.data.cookChoices.map(choice => ({
      name: choice.name,
      planned: choice.need,
      actual: choice.need,
      unit: choice.unit,
      foodId: choice.foodId
    }))
    const preview = clone(this.beforeCook)
    this.applyRows(preview, adjustRows)
    Store.set(preview)
    this.state = preview
    this.setData({ adjusting: true, adjustRows })
  },

  changeActual(e) {
    const index = Number(e.currentTarget.dataset.index)
    const adjustRows = this.data.adjustRows.slice()
    adjustRows[index].actual = e.detail.value
    this.setData({ adjustRows })
  },

  cancelAdjust() {
    Store.set(this.beforeCook)
    this.state = clone(this.beforeCook)
    this.setData({ adjusting: false })
  },

  saveAdjust() {
    const finalState = clone(this.beforeCook)
    const result = this.applyRows(finalState, this.data.adjustRows)
    Store.commit(finalState, { type: 'deductMany', data: { rows: this.data.adjustRows.map(row => ({ foodId: row.foodId, amount: row.actual })) } }).catch(error => wx.showToast({ title: error.message || '同步失败', icon: 'none' }))
    this.state = finalState
    this.setData({ adjusting: false, selected: null, stepsVisible: false })
    this.refreshRecommendations(this.data.meal, true)
    const emptyNames = result.depleted.map(item => item.name)
    if (!emptyNames.length) {
      return wx.showModal({ title: '已经记好啦', content: result.shortages.length ? `${result.shortages.join('、')}库存不足，已经扣到0。` : '已按照实际用量更新库存。', showCancel: false })
    }
    const itemList = finalState.sharedListId ? ['加入个人购物清单', '加入共享购物清单', '暂时不添加'] : ['加入个人购物清单', '暂时不添加']
    wx.showActionSheet({
      itemList,
      success: ({ tapIndex }) => {
        const shouldAdd = tapIndex === 0 || finalState.sharedListId && tapIndex === 1
        if (shouldAdd) {
          const listName = tapIndex === 0 ? 'personal' : 'shared'
          result.depleted.forEach(item => finalState.lists[listName].push({ id: `z${Date.now()}${item.name}`, name: item.name, qty: `1${item.unit}`, by: '我', done: false }))
          Store.commit(finalState, listName === 'shared' ? { type: 'addListItems', data: { items: result.depleted.map(item => ({ id: `z${Date.now()}${item.name}`, name: item.name, qty: `1${item.unit}`, by: '我', done: false })) } } : null)
          this.state = finalState
        }
        wx.showModal({ title: `${emptyNames.join('、')}已经没有了`, content: result.shortages.length ? '库存不足的食材已扣到0，菜谱仍会显示所需数量。' : '库存已归零，并完成本次做饭记录。', showCancel: false })
      },
      fail: () => wx.showModal({ title: `${emptyNames.join('、')}已经没有了`, content: '库存已归零。', showCancel: false })
    })
  }
})
