const Store = require('../../utils/store')
const FoodIcons = require('../../utils/food-icons')
const Auth = require('../../utils/auth')

Page({
  data: { kind: 'personal', pending: [], done: [], hasShared: false },
  onShow() { if (!Auth.guard()) return; if (this.getTabBar && this.getTabBar()) this.getTabBar().setData({ selected: 3 }); this.load(); Store.refresh().then(() => this.load()).catch(() => {}) },
  load() {
    this.state = Store.get()
    const list = this.state.lists[this.data.kind] || []
    this.setData({ pending: list.filter(item => !item.done), done: list.filter(item => item.done), hasShared: Boolean(this.state.sharedListId) })
  },
  switchKind(e) { this.setData({ kind: e.currentTarget.dataset.kind }); this.load() },
  toggle(e) {
    const item = this.state.lists[this.data.kind].find(row => row.id === e.currentTarget.dataset.id)
    if (!item) return
    item.done = !item.done
    Store.commit(this.state, this.data.kind === 'shared' ? { type: 'toggleListItem', data: { itemId: item.id } } : null).catch(error => wx.showToast({ title: error.message || '同步失败', icon: 'none' }))
    this.load()
  },
  remove(e) {
    this.state.lists[this.data.kind] = this.state.lists[this.data.kind].filter(item => item.id !== e.currentTarget.dataset.id)
    Store.commit(this.state, this.data.kind === 'shared' ? { type: 'removeListItem', data: { itemId: e.currentTarget.dataset.id } } : null).catch(error => wx.showToast({ title: error.message || '同步失败', icon: 'none' }))
    this.load()
  },
  add() {
    if (this.data.kind === 'shared' && !this.data.hasShared) return wx.showToast({ title: '请先创建或加入共享食仓', icon: 'none' })
    wx.showModal({ title: '添加一项', editable: true, placeholderText: '食材名称', success: result => { if (result.confirm && result.content) { const name = result.content.trim(); const row = { id: `q${Date.now()}`, name, image: FoodIcons.resolve(name).image, qty: '1份', by: '我', done: false }; this.state.lists[this.data.kind].push(row); Store.commit(this.state, this.data.kind === 'shared' ? { type: 'addListItems', data: { items: [row] } } : null).then(() => this.load()).catch(error => wx.showToast({ title: error.message || '保存失败', icon: 'none' })) } } })
  },
  store() {
    if (!this.data.done.length) return wx.showToast({ title: '请先勾选已购买食材', icon: 'none' })
    wx.showActionSheet({
      itemList: ['拍日期', '手动填写', 'AI估算'],
      success: ({ tapIndex }) => {
        if (tapIndex === 0) return wx.chooseMedia({ count: 1, mediaType: ['image'], sourceType: ['album', 'camera'], success: () => this.commitStore('2026-08-30'), fail: () => {} })
        if (tapIndex === 1) return wx.showModal({ title: '填写到期日期', editable: true, placeholderText: '例如 2026-08-30', success: result => { if (result.confirm && /^\d{4}-\d{2}-\d{2}$/.test(result.content)) this.commitStore(result.content); else if (result.confirm) wx.showToast({ title: '请按年月日填写', icon: 'none' }) } })
        this.commitStore('2026-08-31')
      }
    })
  },
  commitStore(expiry) {
    this.data.done.forEach(item => {
      const matched = String(item.qty).match(/^([\d.]+)(.*)$/)
      const qty = matched ? Number(matched[1]) : 1
      const unit = matched && matched[2] ? matched[2] : '份'
      let food = this.state.inventory.find(existing => existing.name === item.name && existing.unit === unit)
      if (!food) {
        food = { id: `s${Date.now()}${item.id}`, name: item.name, image: FoodIcons.resolve(item.name).image, unit, batches: [] }
        this.state.inventory.push(food)
      }
      food.batches.push({ id: `sb${Date.now()}${item.id}`, qty, expiry })
    })
    this.state.lists[this.data.kind] = this.state.lists[this.data.kind].filter(item => !item.done)
    const mutation = this.data.kind === 'shared' ? { type: 'storePurchased', data: { itemIds: this.data.done.map(item => item.id), expiry } } : null
    Store.commit(this.state, mutation).then(() => { this.load(); wx.showToast({ title: '已批量入库' }) }).catch(error => wx.showToast({ title: error.message || '入库失败', icon: 'none' }))
  }
})
