const Auth = require('../../utils/auth')
const Profile = require('../../utils/profile')

Page({
  data: { stage: 'login', loading: false, error: '', avatar: '', nickname: '' },
  onShow() {
    if (!Auth.isLoggedIn()) return
    const session = Auth.get()
    if (Profile.get()) return this.enter()
    if (session.profilePromptRequired) return this.setData({ stage: 'choice' })
    Profile.ensureDefault()
    this.enter()
  },
  login() {
    if (this.data.loading) return
    this.setData({ loading: true, error: '' })
    Auth.login()
      .then(() => Profile.loadRemote())
      .then(profile => {
        if (profile) return this.enter()
        this.setData({ stage: 'choice', loading: false })
      })
      .catch(error => this.setData({ error: error.message || '登录失败，请稍后再试' }))
      .finally(() => this.setData({ loading: false }))
  },
  useWechatProfile() { this.setData({ stage: 'profile', avatar: '', nickname: '', error: '' }) },
  backToChoice() { this.setData({ stage: 'choice', error: '' }) },
  chooseAvatar(e) { this.setData({ avatar: e.detail.avatarUrl, error: '' }) },
  changeNickname(e) { this.setData({ nickname: e.detail.value, error: '' }) },
  skipProfile() {
    if (this.data.loading) return
    this.setData({ loading: true, error: '' })
    Profile.saveDefault().then(result => {
      if (!result.synced) wx.showToast({ title: '已保存在本机，联网后将同步', icon: 'none' })
      this.enter()
    }).catch(error => this.setData({ error: error.message || '资料保存失败' }))
      .finally(() => this.setData({ loading: false }))
  },
  confirmProfile() {
    if (this.data.loading) return
    if (!this.data.avatar) return this.setData({ error: '请先选择微信头像' })
    if (!this.data.nickname.trim()) return this.setData({ error: '请确认微信昵称' })
    this.setData({ loading: true, error: '' })
    Profile.save({ nickname: this.data.nickname, avatar: this.data.avatar, usesDefaultProfile: false })
      .then(result => {
        if (!result.synced) wx.showToast({ title: '已保存在本机，联网后将同步', icon: 'none' })
        this.enter()
      })
      .catch(error => this.setData({ error: error.message || '资料保存失败' }))
      .finally(() => this.setData({ loading: false }))
  },
  enter() {
    Auth.markProfileReady()
    const token = wx.getStorageSync('guagua-pending-invite')
    if (token) return wx.redirectTo({ url: `/pages/invite/invite?token=${token}` })
    wx.switchTab({ url: '/pages/fridge/fridge' })
  }
})
