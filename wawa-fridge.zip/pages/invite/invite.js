const Auth = require('../../utils/auth')
const Profile = require('../../utils/profile')
const Shared = require('../../utils/shared-pantry')

Page({
  data: { loading: true, joining: false, error: '', pantry: null },
  onLoad(options) {
    this.token = options.token || ''
    if (!this.token) return this.setData({ loading: false, error: '邀请链接不完整' })
    if (!Auth.isLoggedIn()) {
      wx.setStorageSync('guagua-pending-invite', this.token)
      return wx.reLaunch({ url: '/pages/login/login' })
    }
    wx.removeStorageSync('guagua-pending-invite')
    this.preview()
  },
  preview() {
    Shared.call('previewInvite', { token: this.token })
      .then(result => {
        this.setData({ pantry: result.pantry, loading: false })
        if (result.pantry.joined) this.enter(result.pantry.id)
      })
      .catch(error => this.setData({ loading: false, error: error.message || '邀请暂时无法打开' }))
  },
  join() {
    if (this.data.joining) return
    const profile = Profile.ensureDefault()
    this.setData({ joining: true, error: '' })
    Shared.call('join', { token: this.token, profile: { nickname: profile.nickname, avatar: profile.avatarFileID || profile.avatar } })
      .then(result => { Shared.cache(result.pantry); return Shared.list().then(() => Shared.select(result.pantry.id)) })
      .then(() => this.enter())
      .catch(error => this.setData({ error: error.message || '加入失败，请重试' }))
      .finally(() => this.setData({ joining: false }))
  },
  enter(id) {
    const pantryId = id || this.data.pantry && this.data.pantry.id
    Promise.resolve(pantryId ? Shared.select(pantryId) : null).finally(() => wx.switchTab({ url: '/pages/fridge/fridge' }))
  },
  goHome() { wx.switchTab({ url: '/pages/fridge/fridge' }) }
})
