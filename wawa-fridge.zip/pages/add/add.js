const Store = require('../../utils/store')
const FoodIcons = require('../../utils/food-icons')
const Auth = require('../../utils/auth')

const sets = {
  manual: [['/assets/food-categories/generic.png', '新食材', 1, '个', '2026-08-31']],
  photo: [['/assets/food-exact/tomato.png', '番茄', 2, '个', '2026-08-29'], ['/assets/food-exact/egg.png', '鸡蛋', 6, '个', '2026-09-05']],
  receipt: [['/assets/food-exact/tomato.png', '番茄', 2, '个', '2026-08-29'], ['/assets/food-exact/egg.png', '鸡蛋', 6, '个', '2026-09-05'], ['/assets/food-exact/milk.png', '牛奶', 1, '盒', '2026-08-26']],
  barcode: [['/assets/food-exact/milk.png', '低脂牛奶', 1, '盒', '2026-08-30']]
}

Page({
  data: { method: '', title: 'AI识别结果', results: [], selectedCount: 0, success: false },

  onShow() { if (!Auth.guard()) return; if (this.getTabBar && this.getTabBar()) this.getTabBar().setData({ selected: 2 }); Store.refresh().catch(() => {}) },

  choose(e) {
    const method = e.currentTarget.dataset.method
    if (method === 'manual') return this.showResults(method)
    if (method === 'barcode') {
      return wx.scanCode({ success: () => this.showResults(method), fail: () => this.showResults(method) })
    }
    wx.chooseMedia({ count: method === 'receipt' ? 1 : 9, mediaType: ['image'], sourceType: ['album', 'camera'], success: () => this.showResults(method), fail: () => this.showResults(method) })
  },

  showResults(method) {
    const results = sets[method].map((item, index) => ({ id: `${method}${index}`, image: item[0], name: item[1], qty: item[2], unit: item[3], storage: '冷藏', expiry: item[4], checked: true }))
    const titles = { manual: '填写食材信息', photo: '照片识别结果', receipt: '小票识别结果', barcode: '条码识别结果' }
    this.setData({ method, title: titles[method], results, selectedCount: results.length, success: false })
  },

  check(e) {
    const ids = e.detail.value
    const results = this.data.results.map(item => ({ ...item, checked: ids.includes(item.id) }))
    this.setData({ results, selectedCount: ids.length })
  },

  edit(e) {
    const index = Number(e.currentTarget.dataset.index)
    const item = this.data.results[index]
    wx.showModal({ title: '修改食材名称', editable: true, placeholderText: item.name, success: result => { if (result.confirm && result.content) { item.name = result.content.trim(); item.image = FoodIcons.resolve(item.name).image; this.setData({ results: this.data.results }) } } })
  },

  editQty(e) {
    const index = Number(e.currentTarget.dataset.index)
    const results = this.data.results.slice()
    results[index].qty = Math.max(0, Number(e.detail.value) || 0)
    this.setData({ results })
  },

  editExpiry(e) {
    const index = Number(e.currentTarget.dataset.index)
    const results = this.data.results.slice()
    results[index].expiry = e.detail.value
    this.setData({ results })
  },

  dateMode(e) {
    const mode = e.currentTarget.dataset.mode
    if (mode === '手动填写') {
      return wx.showModal({ title: '填写到期日期', editable: true, placeholderText: '例如 2026-08-30', success: result => { if (result.confirm && /^\d{4}-\d{2}-\d{2}$/.test(result.content)) this.setAllExpiry(result.content); else if (result.confirm) wx.showToast({ title: '请按年月日填写', icon: 'none' }) } })
    }
    if (mode === '拍包装日期') return wx.chooseMedia({ count: 1, mediaType: ['image'], sourceType: ['album', 'camera'], success: () => this.setAllExpiry('2026-08-30'), fail: () => {} })
    this.setAllExpiry('2026-08-31')
  },

  setAllExpiry(expiry) {
    this.setData({ results: this.data.results.map(item => ({ ...item, expiry })) })
    wx.showToast({ title: '到期日期已更新' })
  },

  confirm() {
    if (!this.data.selectedCount) return wx.showToast({ title: '请至少选择一项', icon: 'none' })
    const selected = this.data.results.filter(item => item.checked)
    if (selected.some(item => !FoodIcons.normalize(item.name) || item.name === '新食材')) return wx.showToast({ title: '请先填写食材名称', icon: 'none' })
    const state = Store.get()
    const added = []
    selected.forEach(item => {
      item.image = FoodIcons.resolve(item.name).image
      let food = state.inventory.find(existing => existing.name === item.name && existing.unit === item.unit)
      if (!food) {
        food = { id: `f${Date.now()}${item.id}`, name: item.name, image: item.image, unit: item.unit, batches: [] }
        state.inventory.push(food)
      }
      food.batches.push({ id: `b${Date.now()}${item.id}`, qty: item.qty, expiry: item.expiry })
      added.push({ id: food.id, name: food.name, image: food.image, unit: food.unit, batches: [{ id: `cb${Date.now()}${item.id}`, qty: item.qty, expiry: item.expiry }] })
    })
    Store.commit(state, { type: 'addFoods', data: { foods: added } }).then(() => this.setData({ results: [], success: true })).catch(error => wx.showToast({ title: error.message || '保存失败', icon: 'none' }))
  },

  again() { this.setData({ success: false }) },
  goFridge() { wx.switchTab({ url: '/pages/fridge/fridge' }) }
})
