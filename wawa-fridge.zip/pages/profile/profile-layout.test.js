const assert = require('assert')
const fs = require('fs')
const path = require('path')

const profileJs = fs.readFileSync(path.join(__dirname, 'profile.js'), 'utf8')
const profileCss = fs.readFileSync(path.join(__dirname, 'profile.wxss'), 'utf8')
const tabWxml = fs.readFileSync(path.join(__dirname, '../../custom-tab-bar/index.wxml'), 'utf8')

assert.match(tabWxml, /wx:if="\{\{!hidden\}\}"/)
assert.match(profileJs, /setTabBarHidden\(true\)/)
assert.match(profileJs, /onHide\(\) \{ this\.setTabBarHidden\(false\) \}/)
assert.match(profileCss, /bottom:calc\(28rpx \+ env\(safe-area-inset-bottom\)\)/)

console.log('profile panel layer checks passed')
