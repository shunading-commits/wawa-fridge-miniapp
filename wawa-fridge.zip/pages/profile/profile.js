const Store = require('../../utils/store')
const Auth = require('../../utils/auth')
const Profile = require('../../utils/profile')
const Shared = require('../../utils/shared-pantry')

Page({
  data: {
    panel: '',
    reminderDays: [1, 2, 3, 5, 7],
    selectedDay: 3,
    favorites: [],
    userName: '',
    avatar: Profile.DEFAULT_AVATAR,
    draftName: '',
    draftAvatar: Profile.DEFAULT_AVATAR,
    savingProfile: false,
    sharedPantries: [],
    selectedPantry: null,
    invitePath: '',
    sharedLoading: false
  },
  onShow() {
    if (!Auth.guard()) return
    this.setTabBarHidden(Boolean(this.data.panel))
    this.state = Store.get()
    const profile = Profile.ensureDefault()
    this.applyProfile(profile)
    this.setData({ favorites: this.state.favorites || [], selectedDay: this.state.reminderDays || 3 })
    Profile.loadRemote().then(remote => {
      if (remote) this.applyProfile(remote)
      return Profile.retrySync()
    }).then(synced => { if (synced) this.applyProfile(synced) })
    this.refreshShared()
  },
  onHide() { this.setTabBarHidden(false) },
  onUnload() { this.setTabBarHidden(false) },
  setTabBarHidden(hidden) {
    const tabBar = this.getTabBar && this.getTabBar()
    if (tabBar) tabBar.setData({ selected: 4, hidden })
  },
  applyProfile(profile) { this.setData({ userName: profile.nickname, avatar: profile.avatar || Profile.DEFAULT_AVATAR }) },
  editProfile() {
    const profile = Profile.ensureDefault()
    this.setTabBarHidden(true)
    this.setData({ panel: '个人资料', draftName: profile.nickname, draftAvatar: profile.avatar || Profile.DEFAULT_AVATAR })
  },
  chooseAvatar(e) { this.setData({ draftAvatar: e.detail.avatarUrl }) },
  changeNickname(e) { this.setData({ draftName: e.detail.value }) },
  saveProfile() {
    if (this.data.savingProfile) return
    if (!this.data.draftName.trim()) return wx.showToast({ title: '请填写昵称', icon: 'none' })
    this.setData({ savingProfile: true })
    Profile.save({ nickname: this.data.draftName, avatar: this.data.draftAvatar, usesDefaultProfile: false })
      .then(result => {
        this.applyProfile(result.profile)
        this.close()
        wx.showToast({ title: result.synced ? '资料已更新' : '已保存在本机，联网后将同步', icon: 'none' })
      })
      .catch(error => wx.showToast({ title: error.message || '资料保存失败', icon: 'none' }))
      .finally(() => this.setData({ savingProfile: false }))
  },
  open(e) {
    this.setTabBarHidden(true)
    this.setData({ panel: e.currentTarget.dataset.name })
    if (e.currentTarget.dataset.name === '共享清单') this.refreshShared(true)
  },
  close() {
    this.setData({ panel: '' })
    this.setTabBarHidden(false)
  },
  day(e) {
    const selectedDay = this.data.reminderDays[Number(e.detail.value)]
    this.state.reminderDays = selectedDay
    Store.set(this.state)
    this.setData({ selectedDay })
  },
  exportData() {
    wx.setClipboardData({ data: JSON.stringify(Store.get()), success: () => wx.showToast({ title: '数据已复制' }) })
  },
  refreshShared(prepare) {
    this.setData({ sharedLoading: true })
    Shared.list().then(rows => {
      const selected = rows.find(row => row.id === Shared.activeId()) || rows[0] || null
      this.setData({ sharedPantries: rows, selectedPantry: selected, sharedLoading: false, invitePath: '' })
      if (prepare && selected && selected.role === 'owner') this.prepareInvite(selected.id)
    }).catch(() => this.setData({ sharedLoading: false }))
  },
  createShared() {
    const profile = Profile.ensureDefault()
    this.setData({ sharedLoading: true })
    Shared.create(`${profile.nickname}的共享食仓`, { nickname: profile.nickname, avatar: profile.avatarFileID || profile.avatar })
      .then(pantry => { this.setData({ selectedPantry: pantry }); return this.refreshShared(true) })
      .then(() => wx.showToast({ title: '共享食仓已创建' }))
      .catch(error => wx.showToast({ title: error.message || '创建失败', icon: 'none' }))
      .finally(() => this.setData({ sharedLoading: false }))
  },
  prepareInvite(pantryId) {
    Shared.call('invite', { pantryId }).then(result => this.setData({ invitePath: result.path })).catch(() => {})
  },
  selectShared(e) {
    const pantry = this.data.sharedPantries.find(row => row.id === e.currentTarget.dataset.id)
    if (!pantry) return
    Shared.select(pantry.id).then(() => {
      this.setData({ selectedPantry: pantry, invitePath: '' })
      if (pantry.role === 'owner') this.prepareInvite(pantry.id)
      wx.showToast({ title: '已切换共享食仓' })
    })
  },
  removeMember(e) {
    const memberId = e.currentTarget.dataset.id
    wx.showModal({ title: '移除成员', content: '确定将这位成员移出共享食仓吗？', success: result => {
      if (!result.confirm) return
      Shared.call('removeMember', { pantryId: this.data.selectedPantry.id, memberId }).then(() => this.refreshShared(true)).catch(error => wx.showToast({ title: error.message || '移除失败', icon: 'none' }))
    } })
  },
  leaveShared() {
    const pantry = this.data.selectedPantry
    wx.showModal({ title: '退出共享食仓', content: '退出后将不能再查看其中的库存和照片，确定继续吗？', success: result => {
      if (!result.confirm) return
      Shared.call('leave', { pantryId: pantry.id }).then(() => { Shared.clearPantry(pantry.id); this.refreshShared(); wx.showToast({ title: '已退出共享食仓' }) }).catch(error => wx.showToast({ title: error.message || '退出失败', icon: 'none' }))
    } })
  },
  dissolveShared() {
    const pantry = this.data.selectedPantry
    wx.showModal({ title: '解散共享食仓', content: '所有成员将无法继续访问共享数据，确定解散吗？', confirmColor: '#c76f58', success: result => {
      if (!result.confirm) return
      Shared.call('dissolve', { pantryId: pantry.id }).then(() => { Shared.clearPantry(pantry.id); this.refreshShared(); wx.showToast({ title: '共享食仓已解散' }) }).catch(error => wx.showToast({ title: error.message || '解散失败', icon: 'none' }))
    } })
  },
  onShareAppMessage() {
    const pantry = this.data.selectedPantry
    if (this.data.panel === '共享清单' && pantry && pantry.role === 'owner' && this.data.invitePath) return { title: `${pantry.name}邀请你一起管理食材`, path: this.data.invitePath, imageUrl: '/assets/members-strip.jpg' }
    return { title: '呱呱食仓', path: '/pages/fridge/fridge' }
  },
  unregister() {
    wx.showModal({ title: '清除本机数据', content: '将清除当前微信用户在本机的全部呱呱食仓数据，确定继续吗？', success: result => { if (result.confirm) { wx.removeStorageSync(Store.key()); this.onShow(); wx.showToast({ title: '本机数据已清除' }) } } })
  },
  logout() {
    wx.showModal({ title: '退出登录', content: '冰箱数据会保留在本机，下次登录仍可继续使用。', success: result => { if (result.confirm) { Auth.logout(); wx.reLaunch({ url: '/pages/login/login' }) } } })
  },
  feedback() { wx.showToast({ title: '反馈已收到' }) },
  clear() {
    wx.showModal({
      title: '清除库存记录',
      content: '此操作不可恢复，确定继续吗？',
      success: result => {
        if (result.confirm) {
          const state = Store.get()
          Object.keys(state.inventories).forEach(name => { state.inventories[name] = [] })
          state.inventory = []
          state.history = []
          Store.set(state)
          wx.showToast({ title: '已清除' })
        }
      }
    })
  }
})
