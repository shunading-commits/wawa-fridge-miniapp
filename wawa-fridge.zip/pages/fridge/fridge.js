const Store = require('../../utils/store')
const Auth = require('../../utils/auth')
const Dates = require('../../utils/date')
const FoodIcons = require('../../utils/food-icons')
const Shared = require('../../utils/shared-pantry')

Page({
  data: { today: '', fridges: [], currentFridge: '', pantryOptions: [{ id: '', name: '我的食仓' }], pantryIndex: 0, foods: [], moreCount: 0, expiring: [], selected: null, selectedExpired: false, batchLabels: [], batchIndex: 0, useAmount: 1, maxAmount: 1 },
  onShow() {
    if (!Auth.guard()) return
    if (this.getTabBar && this.getTabBar()) this.getTabBar().setData({ selected: 0 })
    this.refreshDate()
    this.load()
    Store.refresh().then(() => this.load()).catch(() => {})
    this.scheduleMidnightRefresh()
  },
  onHide() { this.clearMidnightRefresh() },
  onUnload() { this.clearMidnightRefresh() },
  refreshDate() {
    const now = new Date()
    this.todayISO = Dates.localISO(now)
    this.setData({ today: Dates.display(now) })
  },
  scheduleMidnightRefresh() {
    this.clearMidnightRefresh()
    this.midnightTimer = setTimeout(() => {
      this.refreshDate()
      this.load()
      this.scheduleMidnightRefresh()
    }, Dates.untilNextMidnight())
  },
  clearMidnightRefresh() {
    if (this.midnightTimer) clearTimeout(this.midnightTimer)
    this.midnightTimer = null
  },
  load() {
    const state = Store.get()
    const today = this.todayISO || Dates.localISO()
    const warningDate = Dates.addDaysISO(today, state.reminderDays || 3)
    const foods = state.inventory.map(item => {
      const nearest = item.batches.slice().sort((a, b) => a.expiry.localeCompare(b.expiry))[0]
      return { ...item, total: Store.total(item), nearestBatchId: nearest ? nearest.id : '', nearestExpiry: nearest ? nearest.expiry : '', warning: nearest && nearest.expiry <= warningDate, expired: nearest && nearest.expiry < today }
    }).filter(item => item.total > 0)
    const expiring = foods.filter(item => item.warning).sort((a, b) => a.nearestExpiry.localeCompare(b.nearestExpiry)).slice(0, 3).map(item => ({ ...item, expiryText: item.expired ? '已过期' : item.nearestExpiry === today ? '今天到期' : item.nearestExpiry }))
    this.state = state
    const pantryOptions = Store.pantryOptions()
    const pantryIndex = Math.max(0, pantryOptions.findIndex(row => row.id === (state.sharedListId || '')))
    this.setData({ fridges: state.fridges, currentFridge: state.currentFridge, pantryOptions, pantryIndex, foods, moreCount: Math.max(0, foods.length - 6), expiring })
  },
  switchPantry(e) {
    const option = this.data.pantryOptions[Number(e.detail.value)]
    Store.selectPantry(option.id).then(() => this.load()).catch(error => wx.showToast({ title: error.message || '切换失败', icon: 'none' }))
  },
  switchFridge(e) { Store.switchFridge(this.state, this.data.fridges[Number(e.detail.value)]); this.load() },
  openFood(e) {
    const selected = this.data.foods[Number(e.currentTarget.dataset.index)]
    const maxAmount = Store.total(selected) || 1
    this.setData({ selected, selectedExpired: selected.expired, batchLabels: selected.batches.map(batch => batch.expiry + ' · 剩余' + batch.qty + selected.unit), batchIndex: 0, useAmount: 1, maxAmount })
  },
  closeFood() { this.setData({ selected: null }) },
  changeBatch(e) {
    const batchIndex = Number(e.detail.value)
    const maxAmount = Store.total(this.data.selected) || 1
    this.setData({ batchIndex, maxAmount, useAmount: Math.min(Number(this.data.useAmount) || 1, maxAmount) })
  },
  changeAmount(e) { this.setData({ useAmount: e.detail.value }) },
  adjustAmount(e) {
    const step = Number(e.currentTarget.dataset.step)
    const current = Number(this.data.useAmount) || 1
    this.setData({ useAmount: Math.max(1, Math.min(this.data.maxAmount, current + step)) })
  },
  useFood() {
    const item = this.state.inventory.find(food => food.id === this.data.selected.id)
    const wanted = Number(this.data.useAmount)
    if (!Number.isFinite(wanted) || wanted < 1) return wx.showToast({ title: '请输入至少1' + item.unit, icon: 'none' })
    const amount = Store.deduct(item, wanted)
    this.state.history.unshift({ name: item.name, amount, action: 'used', date: Date.now() })
    Store.commit(this.state, { type: 'deductFood', data: { foodId: item.id, amount: wanted } }).catch(error => wx.showToast({ title: error.message || '同步失败', icon: 'none' }))
    this.afterUse(item)
  },
  afterUse(item) {
    if (Store.total(item) > 0) { wx.showToast({ title: '已扣除所选批次' }); this.setData({ selected: null }); return this.load() }
    this.setData({ selected: null })
    this.load()
    const itemList = this.state.sharedListId ? ['加入个人清单', '加入共享清单', '暂不添加'] : ['加入个人清单', '暂不添加']
    wx.showActionSheet({ alertText: item.name + '没有了', itemList, success: result => { const kind = result.tapIndex === 0 ? 'personal' : this.state.sharedListId && result.tapIndex === 1 ? 'shared' : ''; if (!kind) return; const row = { id: 'z' + Date.now(), name: item.name, qty: '1' + item.unit, by: '我', done: false }; this.state.lists[kind].push(row); Store.commit(this.state, kind === 'shared' ? { type: 'addListItems', data: { items: [row] } } : null) } })
  },
  deleteFood() {
    const selected = this.data.selected
    wx.showModal({ title: '删除全部' + selected.name + '？', content: '冰箱里的' + selected.total + selected.unit + selected.name + '都会被删除。', confirmText: '全部删除', confirmColor: '#c76f58', success: result => {
      if (!result.confirm) return
      this.state.inventory = this.state.inventory.filter(food => food.id !== selected.id)
      this.state.history.unshift({ name: selected.name, amount: selected.total, action: 'deleted', date: Date.now() })
      Store.commit(this.state, { type: 'deleteFood', data: { foodId: selected.id } }).catch(error => wx.showToast({ title: error.message || '同步失败', icon: 'none' }))
      this.setData({ selected: null })
      this.load()
      wx.showToast({ title: selected.name + '已删除', icon: 'none' })
    } })
  },
  handleExpired(e) {
    const action = e.currentTarget.dataset.action
    const item = this.state.inventory.find(food => food.id === this.data.selected.id)
    const batch = item.batches.find(row => row.id === this.data.selected.nearestBatchId)
    if (!batch) return this.setData({ selected: null })
    if (action === 'date') return wx.showModal({ title: '修改到期日期', editable: true, placeholderText: '例如 2026-08-30', success: result => { if (result.confirm && /^\d{4}-\d{2}-\d{2}$/.test(result.content)) { batch.expiry = result.content; Store.commit(this.state, { type: 'setBatchExpiry', data: { foodId: item.id, batchId: batch.id, expiry: result.content } }); this.setData({ selected: null }); this.load() } else if (result.confirm) wx.showToast({ title: '请按年月日填写', icon: 'none' }) } })
    const amount = batch.qty
    item.batches = item.batches.filter(row => row.id !== batch.id)
    this.state.history.unshift({ name: item.name, amount, action: action === 'discard' ? 'discarded' : 'used-expired', date: Date.now() })
    Store.commit(this.state, { type: 'removeBatch', data: { foodId: item.id, batchId: batch.id } }).catch(error => wx.showToast({ title: error.message || '同步失败', icon: 'none' }))
    if (action === 'discard') wx.showToast({ title: '已记录食物浪费' })
    this.afterUse(item)
  },
  changeFoodPhoto() {
    wx.showActionSheet({ itemList: ['拍照', '从相册选择', '恢复默认图标'], success: ({ tapIndex }) => {
      if (tapIndex === 2) return this.saveFoodImage(FoodIcons.resolve(this.data.selected.name).image, false)
      wx.chooseMedia({ count: 1, mediaType: ['image'], sourceType: [tapIndex === 0 ? 'camera' : 'album'], success: result => {
        const path = result.tempFiles[0].tempFilePath
        if (wx.compressImage) wx.compressImage({ src: path, quality: 75, success: compressed => this.persistFoodPhoto(compressed.tempFilePath), fail: () => this.persistFoodPhoto(path) })
        else this.persistFoodPhoto(path)
      } })
    } })
  },
  persistFoodPhoto(path) {
    const food = this.state.inventory.find(row => row.id === this.data.selected.id)
    if (this.state.sharedListId) {
      wx.showLoading({ title: '正在上传' })
      return Shared.uploadFoodPhoto(this.state.sharedListId, food.id, path).then(fileID => this.saveFoodImage(fileID, true)).catch(error => wx.showToast({ title: error.message || '照片上传失败', icon: 'none' })).finally(() => wx.hideLoading())
    }
    if (!wx.saveFile) return this.saveFoodImage(path, true)
    wx.saveFile({ tempFilePath: path, success: result => this.saveFoodImage(result.savedFilePath, true), fail: () => this.saveFoodImage(path, true) })
  },
  saveFoodImage(image, customImage) {
    const food = this.state.inventory.find(row => row.id === this.data.selected.id)
    food.image = image
    food.customImage = customImage
    this.setData({ selected: { ...this.data.selected, image, customImage } })
    Store.commit(this.state, { type: 'setFoodImage', data: { foodId: food.id, image, customImage } }).then(() => { this.load(); wx.showToast({ title: customImage ? '照片已更换' : '已恢复默认图标' }) }).catch(error => wx.showToast({ title: error.message || '保存失败', icon: 'none' }))
  }
})
