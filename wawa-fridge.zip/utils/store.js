const KEY = 'wawa-fridge-state-v6'
const FoodIcons = require('./food-icons')
const Auth = require('./auth')
const Shared = require('./shared-pantry')

const mine = []
const seed = {
  currentFridge: '我的冰箱',
  fridges: ['我的冰箱'],
  inventories: { '我的冰箱': mine },
  inventory: mine,
  lists: { personal: [], shared: [] },
  sharedListId: '',
  history: [],
  favorites: [],
  reminderDays: 3
}

function clone(value) { return JSON.parse(JSON.stringify(value)) }
function key() { const session = Auth.get(); return `${KEY}:${session && session.openid || 'guest'}` }

function init() {
  const storageKey = key()
  if (!wx.getStorageSync(storageKey)) wx.setStorageSync(storageKey, clone(seed))
}

function personal() {
  init()
  const storageKey = key()
  const state = wx.getStorageSync(storageKey)
  state.inventories = state.inventories || { [state.currentFridge]: state.inventory || [] }
  if (!state.inventories[state.currentFridge]) state.inventories[state.currentFridge] = []
  state.inventory = state.inventories[state.currentFridge]
  state.lists = state.lists || { personal: [], shared: [] }
  state.lists.personal = state.lists.personal || []
  state.lists.shared = state.lists.shared || []
  state.favorites = state.favorites || []
  state.reminderDays = state.reminderDays || 3
  let imagesChanged = false
  Object.values(state.inventories).forEach(inventory => inventory.forEach(item => {
    const image = item.customImage ? item.image : FoodIcons.resolve(item.name).image
    if (item.image !== image) { item.image = image; imagesChanged = true }
  }))
  Object.values(state.lists).forEach(list => list.forEach(item => {
    const image = item.customImage ? item.image : FoodIcons.resolve(item.name).image
    if (item.image !== image) { item.image = image; imagesChanged = true }
  }))
  if (imagesChanged) wx.setStorageSync(storageKey, state)
  return state
}

function get() {
  const local = personal()
  const pantryId = Shared.activeId()
  const shared = Shared.cached(pantryId)
  if (!pantryId || !shared) return local
  const inventory = shared.inventory || []
  return {
    ...local,
    currentFridge: shared.name,
    fridges: [shared.name],
    inventories: { [shared.name]: inventory },
    inventory,
    lists: { personal: local.lists.personal || [], shared: shared.sharedList || [] },
    sharedListId: shared.id,
    sharedPantry: shared
  }
}

function set(state) {
  if (state.sharedListId) {
    const local = personal()
    local.lists.personal = state.lists.personal || []
    local.favorites = state.favorites || []
    local.reminderDays = state.reminderDays || 3
    wx.setStorageSync(key(), local)
    Shared.cache({ ...state.sharedPantry, inventory: state.inventory || [], sharedList: state.lists.shared || [] })
    return
  }
  state.inventories = state.inventories || {}
  state.inventories[state.currentFridge] = state.inventory || []
  wx.setStorageSync(key(), state)
}

function refresh() { return Shared.refresh().then(() => get()) }

function commit(state, mutation) {
  set(state)
  if (!state.sharedListId || !mutation) return Promise.resolve(state)
  return Shared.mutate(state.sharedListId, mutation).then(() => get())
}

function pantryOptions() {
  const rows = Shared.context().pantries || []
  return [{ id: '', name: '我的食仓' }].concat(rows.map(row => ({ id: row.id, name: row.name })))
}

function selectPantry(id) { return Shared.select(id).then(() => get()) }

function switchFridge(state, nextFridge) {
  set(state)
  state.currentFridge = nextFridge
  if (!state.inventories[nextFridge]) state.inventories[nextFridge] = []
  state.inventory = state.inventories[nextFridge]
  set(state)
  return state
}

function total(item) {
  return item.batches.reduce((sum, batch) => sum + Number(batch.qty || 0), 0)
}

function deduct(item, requested) {
  let remaining = Math.max(0, Number(requested) || 0)
  let used = 0
  item.batches.sort((a, b) => a.expiry.localeCompare(b.expiry))
  item.batches.forEach(batch => {
    const amount = Math.min(Number(batch.qty) || 0, remaining)
    batch.qty = Math.max(0, (Number(batch.qty) || 0) - amount)
    remaining -= amount
    used += amount
  })
  item.batches = item.batches.filter(batch => batch.qty > 0)
  return used
}

module.exports = { KEY, key, init, get, personal, set, refresh, commit, pantryOptions, selectPantry, switchFridge, total, deduct, seed }
