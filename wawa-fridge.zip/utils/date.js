const WEEKDAYS = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']

function pad(value) { return String(value).padStart(2, '0') }

function localISO(date) {
  const value = date || new Date()
  return `${value.getFullYear()}-${pad(value.getMonth() + 1)}-${pad(value.getDate())}`
}

function display(date) {
  const value = date || new Date()
  return `${value.getMonth() + 1}月${value.getDate()}日 · ${WEEKDAYS[value.getDay()]}`
}

function fromISO(iso) {
  const parts = String(iso).split('-').map(Number)
  return new Date(parts[0], parts[1] - 1, parts[2])
}

function addDaysISO(iso, days) {
  const value = fromISO(iso)
  value.setDate(value.getDate() + Number(days || 0))
  return localISO(value)
}

function untilNextMidnight(date) {
  const value = date || new Date()
  const next = new Date(value.getFullYear(), value.getMonth(), value.getDate() + 1)
  return Math.max(1000, next.getTime() - value.getTime() + 100)
}

module.exports = { WEEKDAYS, localISO, display, addDaysISO, untilNextMidnight }
