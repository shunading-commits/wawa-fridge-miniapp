const assert = require('assert')
const storage = { 'guagua-auth-v1': { openid: 'user-a' } }
global.wx = {
  getStorageSync: key => storage[key],
  setStorageSync: (key, value) => { storage[key] = value },
  removeStorageSync: key => { delete storage[key] },
  cloud: {
    callFunction: ({ data }) => Promise.resolve({ result: data.action === 'list' ? { pantries: [] } : {} })
  }
}

const Shared = require('./shared-pantry')
Shared.cache({ id: 'pantry-a', name: '朋友食仓', inventory: [{ id: 'food-a', name: '苹果', image: 'cloud://apple.jpg', customImage: true, unit: '个', batches: [{ id: 'b1', qty: 2, expiry: '2026-08-30' }] }], sharedList: [], members: [], role: 'member' })
wx.setStorageSync(Shared.CONTEXT_KEY, { activeId: 'pantry-a', pantries: [{ id: 'pantry-a', name: '朋友食仓' }] })

const Store = require('./store')
const shared = Store.get()
assert.strictEqual(shared.sharedListId, 'pantry-a')
assert.strictEqual(shared.inventory[0].image, 'cloud://apple.jpg')
assert.strictEqual(shared.inventory[0].customImage, true)

Shared.select('').then(() => {
  const mine = Store.get()
  assert.strictEqual(mine.sharedListId, '')
  assert.deepStrictEqual(mine.inventory, [])
  console.log('shared pantry cache and isolation checks passed')
})
