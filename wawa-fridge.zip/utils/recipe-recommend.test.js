const assert = require('assert')
const Recommend = require('./recipe-recommend')

const recipes = [
  { name: '番茄蛋', ingredients: [['番茄', 1], ['鸡蛋', 2]] },
  { name: '牛奶蛋', ingredients: [['牛奶', 1], ['鸡蛋', 1]] },
  { name: '白粥', ingredients: [['剩饭', 1]] },
  { name: '生菜汤', ingredients: [['生菜', 1]] }
]
const inventory = [
  { name: '番茄', batches: [{ qty: 1, expiry: '2026-08-27' }] },
  { name: '鸡蛋', batches: [{ qty: 2, expiry: '2026-09-20' }] }
]
const ranked = Recommend.rank(recipes, inventory, 3, Date.parse('2026-08-26T00:00:00'))
assert.strictEqual(ranked[0].name, '番茄蛋')
assert.strictEqual(ranked[0].complete, true)
assert.strictEqual(ranked[0].expiring, 1)
const changed = Recommend.rank(recipes, [{ name: '剩饭', batches: [{ qty: 1, expiry: '2026-09-20' }] }], 3, Date.parse('2026-08-26T00:00:00'))
assert.strictEqual(changed[0].name, '白粥')
const first = Recommend.batch(ranked, 0, 2).map(item => item.name)
const second = Recommend.batch(ranked, 2, 2).map(item => item.name)
assert.strictEqual(first.some(name => second.includes(name)), false)
console.log('recipe recommendation checks passed')
