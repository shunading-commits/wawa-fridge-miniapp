const assert = require('assert')

const storage = {}
let redirected = ''
global.wx = {
  getStorageSync: key => storage[key],
  setStorageSync: (key, value) => { storage[key] = value },
  removeStorageSync: key => { delete storage[key] },
  reLaunch: ({ url }) => { redirected = url },
  cloud: { init: () => {}, callFunction: () => Promise.resolve({ result: { openid: 'user-a' } }) }
}

const Auth = require('./auth')
const Store = require('./store')

;(async () => {
  await Auth.login()
  assert.strictEqual(Auth.get().openid, 'user-a')
  assert.strictEqual(Auth.get().profilePromptRequired, true)
  Auth.markProfileReady()
  assert.strictEqual(Auth.get().profilePromptRequired, false)
  assert.strictEqual(Auth.guard(), true)
  const firstKey = Store.key()
  assert.deepStrictEqual(Store.seed.inventory, [])
  assert.deepStrictEqual(Store.seed.lists, { personal: [], shared: [] })
  wx.setStorageSync(Auth.KEY, { openid: 'user-b' })
  assert.notStrictEqual(Store.key(), firstKey)
  Auth.logout()
  assert.strictEqual(Auth.guard(), false)
  assert.strictEqual(redirected, '/pages/login/login')
  console.log('wechat login checks passed')
})().catch(error => { console.error(error); process.exit(1) })
