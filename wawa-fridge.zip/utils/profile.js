const Auth = require('./auth')

const KEY = 'guagua-profile-v1'
const DEFAULT_AVATAR = '/assets/mascot-exact/sitting.png'

function key(openid) {
  const session = Auth.get()
  return `${KEY}:${openid || session && session.openid || 'guest'}`
}

function suffix(openid) {
  let hash = 0
  String(openid || '').split('').forEach(char => { hash = ((hash * 31) + char.charCodeAt(0)) >>> 0 })
  return String(hash % 1000).padStart(3, '0')
}

function defaultProfile(openid) {
  return {
    nickname: `食仓用户${suffix(openid)}`,
    avatar: DEFAULT_AVATAR,
    avatarFileID: '',
    usesDefaultProfile: true,
    profileChoiceMade: true,
    syncPending: false,
    updatedAt: Date.now()
  }
}

function get() { return wx.getStorageSync(key()) || null }

function set(profile) {
  const value = { ...profile, updatedAt: profile.updatedAt || Date.now() }
  wx.setStorageSync(key(), value)
  return value
}

function ensureDefault() {
  const current = get()
  if (current) return current
  const session = Auth.get()
  return set(defaultProfile(session && session.openid))
}

function call(data) {
  if (!wx.cloud || !wx.cloud.callFunction) return Promise.reject(new Error('云端资料服务暂不可用'))
  return wx.cloud.callFunction({ name: 'userProfile', data }).then(({ result }) => result || {})
}

function loadRemote() {
  const local = get()
  if (local && local.syncPending) return Promise.resolve(local)
  return call({ action: 'get' }).then(result => {
    if (!result.profile) return get()
    return set({ ...result.profile, avatar: result.profile.avatarFileID || DEFAULT_AVATAR, syncPending: false })
  }).catch(() => get())
}

function persistAvatar(path) {
  if (!path || path === DEFAULT_AVATAR || path.startsWith('cloud://') || !wx.saveFile) return Promise.resolve(path || DEFAULT_AVATAR)
  return new Promise(resolve => wx.saveFile({ tempFilePath: path, success: result => resolve(result.savedFilePath), fail: () => resolve(path) }))
}

function uploadAvatar(profile) {
  const avatar = profile.avatar || DEFAULT_AVATAR
  if (profile.usesDefaultProfile || avatar === DEFAULT_AVATAR) return Promise.resolve({ avatar: DEFAULT_AVATAR, avatarFileID: '' })
  if (profile.avatarFileID && (avatar === profile.avatarFileID || avatar.startsWith('cloud://'))) {
    return Promise.resolve({ avatar: profile.avatarFileID, avatarFileID: profile.avatarFileID })
  }
  if (!wx.cloud || !wx.cloud.uploadFile) return persistAvatar(avatar).then(saved => Promise.reject({ localAvatar: saved }))
  const session = Auth.get()
  return wx.cloud.uploadFile({
    cloudPath: `user-avatars/${session.openid}/${Date.now()}.png`,
    filePath: avatar
  }).then(result => ({ avatar: result.fileID, avatarFileID: result.fileID })).catch(() => persistAvatar(avatar).then(saved => Promise.reject({ localAvatar: saved })))
}

function save(input) {
  const session = Auth.get()
  if (!session || !session.openid) return Promise.reject(new Error('请先登录'))
  const nickname = String(input.nickname || '').trim().slice(0, 20)
  if (!nickname) return Promise.reject(new Error('请填写昵称'))
  const base = {
    ...input,
    nickname,
    avatar: input.avatar || DEFAULT_AVATAR,
    avatarFileID: input.avatarFileID || '',
    usesDefaultProfile: Boolean(input.usesDefaultProfile),
    profileChoiceMade: true,
    updatedAt: Date.now()
  }
  return uploadAvatar(base).then(avatar => {
    const pending = set({ ...base, ...avatar, syncPending: true })
    return call({
      action: 'save',
      nickname: pending.nickname,
      avatarFileID: pending.avatarFileID,
      usesDefaultProfile: pending.usesDefaultProfile
    }).then(result => ({ profile: set({ ...(result.profile || pending), avatar: pending.avatar, syncPending: false }), synced: true }))
      .catch(() => ({ profile: pending, synced: false }))
  }).catch(error => {
    const pending = set({ ...base, avatar: error && error.localAvatar || base.avatar, syncPending: true })
    return { profile: pending, synced: false }
  })
}

function saveDefault() {
  const session = Auth.get()
  return save(defaultProfile(session && session.openid))
}

function retrySync() {
  const current = get()
  if (!current || !current.syncPending) return Promise.resolve(current)
  return save(current).then(result => result.profile)
}

module.exports = { KEY, DEFAULT_AVATAR, key, suffix, defaultProfile, get, set, ensureDefault, loadRemote, save, saveDefault, retrySync }
