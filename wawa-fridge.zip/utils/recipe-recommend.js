function total(food) {
  return (food && food.batches || []).reduce((sum, batch) => sum + Math.max(0, Number(batch.qty) || 0), 0)
}

function daysUntil(date, now) {
  const target = Date.parse(`${date}T00:00:00`)
  if (!Number.isFinite(target)) return Infinity
  return Math.ceil((target - now) / 86400000)
}

function rank(recipes, inventory, reminderDays, now) {
  const foods = {}
  ;(inventory || []).forEach(food => { foods[food.name] = food })
  const today = now || Date.now()
  return (recipes || []).map((recipe, index) => {
    let matched = 0
    let supply = 0
    let expiring = 0
    recipe.ingredients.forEach(([name, need]) => {
      const food = foods[name]
      const home = total(food)
      if (home > 0) matched += 1
      supply += Math.min(1, home / Math.max(need, 0.01))
      if (home > 0 && (food.batches || []).some(batch => daysUntil(batch.expiry, today) <= reminderDays)) expiring += 1
    })
    const kinds = recipe.ingredients.length || 1
    const complete = recipe.ingredients.every(([name, need]) => total(foods[name]) >= need)
    const score = (complete ? 1000 : 0) + supply / kinds * 100 + matched / kinds * 20 + expiring * 10
    const hint = complete ? '家中食材齐全' : matched ? `已有${matched}/${kinds}种食材` : '需要补充食材'
    return { ...recipe, score, complete, matched, expiring, hint, _index: index }
  }).sort((a, b) => b.score - a.score || a._index - b._index)
}

function batch(items, offset, size) {
  if (!items.length) return []
  if (items.length <= size) return items.slice()
  const start = offset % items.length
  return Array.from({ length: Math.min(size, items.length) }, (_, index) => items[(start + index) % items.length])
}

module.exports = { rank, batch }
