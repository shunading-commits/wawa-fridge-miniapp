const Auth = require('./auth')

const CONTEXT_KEY = 'guagua-shared-context-v1'
const cacheKey = id => `guagua-shared-cache-v1:${Auth.get() && Auth.get().openid || 'guest'}:${id}`

function call(action, data) {
  if (!wx.cloud || !wx.cloud.callFunction) return Promise.reject(new Error('共享服务暂不可用'))
  return wx.cloud.callFunction({ name: 'sharedPantry', data: { action, ...(data || {}) } }).then(({ result }) => result || {})
}

function context() { return wx.getStorageSync(CONTEXT_KEY) || { activeId: '', pantries: [] } }
function saveContext(value) { wx.setStorageSync(CONTEXT_KEY, value); return value }
function activeId() { return context().activeId || '' }

function list() {
  return call('list').then(result => {
    const current = context()
    const rows = result.pantries || []
    if (current.activeId && !rows.some(row => row.id === current.activeId)) current.activeId = ''
    current.pantries = rows.map(row => ({ id: row.id, name: row.name, role: row.role, members: row.members }))
    saveContext(current)
    return current.pantries
  })
}

function get(id) {
  return call('get', { pantryId: id }).then(result => { if (result.pantry) wx.setStorageSync(cacheKey(id), result.pantry); return result.pantry })
}

function refresh() {
  return list().then(() => activeId() ? get(activeId()) : null)
}

function select(id) {
  const current = context()
  current.activeId = id || ''
  saveContext(current)
  return id ? get(id) : Promise.resolve(null)
}

function cached(id) { return id ? wx.getStorageSync(cacheKey(id)) || null : null }
function cache(pantry) { if (pantry && pantry.id) wx.setStorageSync(cacheKey(pantry.id), pantry); return pantry }

function create(name, profile) {
  return call('create', { name, profile }).then(result => { cache(result.pantry); return list().then(() => select(result.pantry.id)).then(() => result.pantry) })
}

function mutate(pantryId, mutation) {
  return call('mutate', { pantryId, mutation }).then(result => cache(result.pantry))
}

function uploadFoodPhoto(pantryId, foodId, filePath) {
  const session = Auth.get()
  if (!session || !session.openid) return Promise.reject(new Error('请先登录'))
  return wx.cloud.uploadFile({ cloudPath: `shared-food-photos/${pantryId}/${foodId}/${Date.now()}.jpg`, filePath }).then(result => result.fileID)
}

function clearPantry(id) {
  wx.removeStorageSync(cacheKey(id))
  const current = context()
  current.pantries = current.pantries.filter(row => row.id !== id)
  if (current.activeId === id) current.activeId = ''
  saveContext(current)
}

module.exports = { CONTEXT_KEY, call, context, activeId, list, get, refresh, select, cached, cache, create, mutate, uploadFoodPhoto, clearPantry }
