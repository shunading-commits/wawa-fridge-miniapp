const KEY = 'guagua-auth-v1'

function get() { return wx.getStorageSync(KEY) || null }
function isLoggedIn() { const session = get(); return Boolean(session && session.openid) }

function login() {
  if (!wx.cloud || !wx.cloud.callFunction) return Promise.reject(new Error('请先在微信开发者工具中开通云开发'))
  wx.cloud.init({ traceUser: true })
  return wx.cloud.callFunction({ name: 'login' }).then(({ result }) => {
    if (!result || !result.openid) throw new Error('没有取得微信用户身份，请重新登录')
    const session = { openid: result.openid, loggedAt: Date.now(), profilePromptRequired: true }
    wx.setStorageSync(KEY, session)
    return session
  })
}

function guard() {
  if (isLoggedIn()) return true
  wx.reLaunch({ url: '/pages/login/login' })
  return false
}

function logout() { wx.removeStorageSync(KEY) }

function markProfileReady() {
  const session = get()
  if (!session) return
  wx.setStorageSync(KEY, { ...session, profilePromptRequired: false })
}

module.exports = { KEY, get, isLoggedIn, login, guard, logout, markProfileReady }
