const assert = require('assert')

const storage = { 'guagua-auth-v1': { openid: 'user-a' } }
global.wx = {
  getStorageSync: key => storage[key],
  setStorageSync: (key, value) => { storage[key] = value },
  saveFile: ({ tempFilePath, success }) => success({ savedFilePath: `saved:${tempFilePath}` }),
  cloud: {
    uploadFile: ({ filePath }) => Promise.resolve({ fileID: `cloud://${filePath}` }),
    callFunction: ({ data }) => Promise.resolve({ result: data.action === 'get' ? {} : { profile: data } })
  }
}

const Profile = require('./profile')

;(async () => {
  const fallback = Profile.ensureDefault()
  assert.match(fallback.nickname, /^食仓用户\d{3}$/)
  assert.strictEqual(fallback.avatar, Profile.DEFAULT_AVATAR)
  assert.strictEqual(Profile.defaultProfile('user-a').nickname, fallback.nickname)

  const result = await Profile.save({ nickname: '  呱呱  ', avatar: 'wxfile://avatar.png', usesDefaultProfile: false })
  assert.strictEqual(result.synced, true)
  assert.strictEqual(result.profile.nickname, '呱呱')
  assert.strictEqual(result.profile.avatar, 'cloud://wxfile://avatar.png')
  assert.strictEqual(Profile.get().syncPending, false)
  console.log('profile checks passed')
})().catch(error => { console.error(error); process.exit(1) })
