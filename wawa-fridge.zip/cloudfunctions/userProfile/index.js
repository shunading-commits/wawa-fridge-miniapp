const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const profiles = db.collection('user_profiles')

function clean(data) {
  return {
    nickname: String(data.nickname || '').trim().slice(0, 20),
    avatarFileID: String(data.avatarFileID || ''),
    usesDefaultProfile: Boolean(data.usesDefaultProfile),
    profileChoiceMade: true
  }
}

exports.main = async event => {
  const { OPENID } = cloud.getWXContext()
  if (event.action === 'get') {
    try {
      const result = await profiles.doc(OPENID).get()
      return { profile: result.data }
    } catch (error) {
      return { profile: null }
    }
  }

  if (event.action !== 'save') throw new Error('不支持的资料操作')
  const profile = clean(event)
  if (!profile.nickname) throw new Error('昵称不能为空')
  profile.updatedAt = db.serverDate()
  await profiles.doc(OPENID).set({ data: profile })
  return { profile: { ...profile, updatedAt: Date.now() } }
}
