const cloud = require('wx-server-sdk')
const crypto = require('crypto')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const pantries = db.collection('shared_pantries')
const invites = db.collection('shared_invites')

const clone = value => JSON.parse(JSON.stringify(value || null))
const id = prefix => prefix + crypto.randomBytes(8).toString('hex')
const cleanText = (value, max) => String(value || '').trim().slice(0, max)
const cleanProfile = data => ({
  id: id('m'),
  openid: data.openid,
  nickname: cleanText(data.nickname, 20) || '食仓成员',
  avatar: cleanText(data.avatar, 500),
  joinedAt: Date.now()
})

function output(pantry, openid) {
  const member = (pantry.members || []).find(row => row.openid === openid)
  return {
    id: pantry._id,
    name: pantry.name,
    role: pantry.ownerOpenid === openid ? 'owner' : 'member',
    members: (pantry.members || []).map(row => ({ id: row.id, nickname: row.nickname, avatar: row.avatar, owner: row.openid === pantry.ownerOpenid })),
    inventory: clone(pantry.inventory) || [],
    sharedList: clone(pantry.sharedList) || [],
    revision: pantry.revision || 0,
    joined: Boolean(member)
  }
}

function requireMember(pantry, openid) {
  if (!pantry || pantry.status !== 'active' || !(pantry.memberOpenids || []).includes(openid)) throw new Error('你已不在这个共享食仓中')
}

function requireOwner(pantry, openid) {
  requireMember(pantry, openid)
  if (pantry.ownerOpenid !== openid) throw new Error('只有房主可以进行此操作')
}

function total(food) {
  return (food.batches || []).reduce((sum, batch) => sum + Number(batch.qty || 0), 0)
}

function deduct(food, requested) {
  let left = Math.max(0, Number(requested) || 0)
  ;(food.batches || []).sort((a, b) => String(a.expiry).localeCompare(String(b.expiry))).forEach(batch => {
    const used = Math.min(Number(batch.qty) || 0, left)
    batch.qty = Math.max(0, (Number(batch.qty) || 0) - used)
    left -= used
  })
  food.batches = (food.batches || []).filter(batch => Number(batch.qty) > 0)
}

function addFoods(inventory, foods) {
  ;(foods || []).forEach(row => {
    const unit = cleanText(row.unit, 10) || '份'
    const name = cleanText(row.name, 30)
    if (!name) return
    let food = inventory.find(item => item.name === name && item.unit === unit)
    if (!food) {
      food = { id: cleanText(row.id, 80) || id('f'), name, unit, image: cleanText(row.image, 500), batches: [] }
      inventory.push(food)
    }
    ;(row.batches || []).forEach(batch => food.batches.push({ id: cleanText(batch.id, 80) || id('b'), qty: Math.max(0, Number(batch.qty) || 0), expiry: cleanText(batch.expiry, 10) }))
  })
}

function applyMutation(pantry, mutation) {
  const inventory = clone(pantry.inventory) || []
  const list = clone(pantry.sharedList) || []
  const data = mutation.data || {}
  if (mutation.type === 'addFoods') addFoods(inventory, data.foods)
  else if (mutation.type === 'deductFood') {
    const food = inventory.find(row => row.id === data.foodId)
    if (food) deduct(food, data.amount)
  } else if (mutation.type === 'deductMany') {
    ;(data.rows || []).forEach(row => { const food = inventory.find(item => item.id === row.foodId); if (food) deduct(food, row.amount) })
  } else if (mutation.type === 'deleteFood') {
    pantry.inventory = inventory.filter(row => row.id !== data.foodId)
    pantry.sharedList = list
    return pantry
  } else if (mutation.type === 'setBatchExpiry') {
    const food = inventory.find(row => row.id === data.foodId)
    const batch = food && food.batches.find(row => row.id === data.batchId)
    if (batch) batch.expiry = cleanText(data.expiry, 10)
  } else if (mutation.type === 'removeBatch') {
    const food = inventory.find(row => row.id === data.foodId)
    if (food) food.batches = food.batches.filter(row => row.id !== data.batchId)
  } else if (mutation.type === 'setFoodImage') {
    const food = inventory.find(row => row.id === data.foodId)
    if (food) { food.image = cleanText(data.image, 500); food.customImage = Boolean(data.customImage) }
  } else if (mutation.type === 'addListItems') {
    ;(data.items || []).forEach(row => list.push({ id: cleanText(row.id, 80) || id('q'), name: cleanText(row.name, 30), qty: cleanText(row.qty, 20) || '1份', by: cleanText(row.by, 20) || '成员', image: cleanText(row.image, 500), done: false }))
  } else if (mutation.type === 'toggleListItem') {
    const row = list.find(item => item.id === data.itemId)
    if (row) row.done = !row.done
  } else if (mutation.type === 'removeListItem') {
    pantry.sharedList = list.filter(row => row.id !== data.itemId)
    pantry.inventory = inventory
    return pantry
  } else if (mutation.type === 'storePurchased') {
    const selected = list.filter(row => (data.itemIds || []).includes(row.id))
    addFoods(inventory, selected.map(row => {
      const match = String(row.qty).match(/^([\d.]+)(.*)$/)
      return { name: row.name, image: row.image, unit: match && match[2] || '份', batches: [{ qty: match ? Number(match[1]) : 1, expiry: cleanText(data.expiry, 10) }] }
    }))
    pantry.sharedList = list.filter(row => !(data.itemIds || []).includes(row.id))
    pantry.inventory = inventory
    return pantry
  } else throw new Error('不支持的共享操作')
  pantry.inventory = inventory.filter(food => total(food) > 0)
  pantry.sharedList = list
  return pantry
}

async function getPantry(pantryId) {
  const result = await pantries.doc(pantryId).get()
  return result.data
}

exports.main = async event => {
  const { OPENID } = cloud.getWXContext()
  const action = event.action

  if (action === 'list') {
    const result = await pantries.where({ memberOpenids: OPENID, status: 'active' }).limit(20).get()
    return { pantries: result.data.map(row => output(row, OPENID)) }
  }

  if (action === 'create') {
    const existing = await pantries.where({ ownerOpenid: OPENID, status: 'active' }).limit(1).get()
    if (existing.data.length) return { pantry: output(existing.data[0], OPENID) }
    const owner = cleanProfile({ ...event.profile, openid: OPENID })
    const data = {
      name: cleanText(event.name, 24) || `${owner.nickname}的共享食仓`,
      ownerOpenid: OPENID,
      members: [owner],
      memberOpenids: [OPENID],
      inventory: [],
      sharedList: [],
      revision: 1,
      status: 'active',
      createdAt: Date.now(),
      updatedAt: Date.now()
    }
    const result = await pantries.add({ data })
    return { pantry: output({ ...data, _id: result._id }, OPENID) }
  }

  if (action === 'get') {
    const pantry = await getPantry(event.pantryId)
    requireMember(pantry, OPENID)
    return { pantry: output(pantry, OPENID) }
  }

  if (action === 'invite') {
    const pantry = await getPantry(event.pantryId)
    requireOwner(pantry, OPENID)
    const token = crypto.randomBytes(16).toString('hex')
    await invites.doc(token).set({ data: { pantryId: pantry._id, createdBy: OPENID, expiresAt: Date.now() + 24 * 60 * 60 * 1000, usedBy: '', createdAt: Date.now() } })
    return { token, path: `/pages/invite/invite?token=${token}` }
  }

  if (action === 'previewInvite') {
    const invitation = (await invites.doc(event.token).get()).data
    if (!invitation || invitation.expiresAt < Date.now() || invitation.usedBy && invitation.usedBy !== OPENID) throw new Error('邀请已失效，请让房主重新发送')
    const pantry = await getPantry(invitation.pantryId)
    if (pantry.status !== 'active') throw new Error('这个共享食仓已解散')
    const owner = pantry.members.find(row => row.openid === pantry.ownerOpenid)
    return { pantry: { id: pantry._id, name: pantry.name, owner: { nickname: owner.nickname, avatar: owner.avatar }, joined: pantry.memberOpenids.includes(OPENID) } }
  }

  if (action === 'join') {
    return db.runTransaction(async transaction => {
      const invitation = (await transaction.collection('shared_invites').doc(event.token).get()).data
      if (!invitation || invitation.expiresAt < Date.now() || invitation.usedBy && invitation.usedBy !== OPENID) throw new Error('邀请已失效，请让房主重新发送')
      const ref = transaction.collection('shared_pantries').doc(invitation.pantryId)
      const pantry = (await ref.get()).data
      if (pantry.status !== 'active') throw new Error('这个共享食仓已解散')
      if (!pantry.memberOpenids.includes(OPENID)) {
        pantry.members.push(cleanProfile({ ...event.profile, openid: OPENID }))
        pantry.memberOpenids.push(OPENID)
        pantry.revision += 1
        pantry.updatedAt = Date.now()
        await ref.update({ data: { members: pantry.members, memberOpenids: pantry.memberOpenids, revision: pantry.revision, updatedAt: pantry.updatedAt } })
      }
      await transaction.collection('shared_invites').doc(event.token).update({ data: { usedBy: OPENID, usedAt: Date.now() } })
      return { pantry: output(pantry, OPENID) }
    })
  }

  if (action === 'mutate') {
    return db.runTransaction(async transaction => {
      const ref = transaction.collection('shared_pantries').doc(event.pantryId)
      const pantry = (await ref.get()).data
      requireMember(pantry, OPENID)
      applyMutation(pantry, event.mutation || {})
      pantry.revision = (pantry.revision || 0) + 1
      pantry.updatedAt = Date.now()
      await ref.update({ data: { inventory: pantry.inventory, sharedList: pantry.sharedList, revision: pantry.revision, updatedAt: pantry.updatedAt } })
      return { pantry: output(pantry, OPENID) }
    })
  }

  if (action === 'removeMember') {
    const pantry = await getPantry(event.pantryId)
    requireOwner(pantry, OPENID)
    const member = pantry.members.find(row => row.id === event.memberId)
    if (!member || member.openid === pantry.ownerOpenid) throw new Error('不能移除房主')
    const members = pantry.members.filter(row => row.id !== event.memberId)
    const memberOpenids = pantry.memberOpenids.filter(row => row !== member.openid)
    await pantries.doc(pantry._id).update({ data: { members, memberOpenids, revision: pantry.revision + 1, updatedAt: Date.now() } })
    return { ok: true }
  }

  if (action === 'leave') {
    const pantry = await getPantry(event.pantryId)
    requireMember(pantry, OPENID)
    if (pantry.ownerOpenid === OPENID) throw new Error('房主不能退出，请解散共享食仓')
    const members = pantry.members.filter(row => row.openid !== OPENID)
    const memberOpenids = pantry.memberOpenids.filter(row => row !== OPENID)
    await pantries.doc(pantry._id).update({ data: { members, memberOpenids, revision: pantry.revision + 1, updatedAt: Date.now() } })
    return { ok: true }
  }

  if (action === 'dissolve') {
    const pantry = await getPantry(event.pantryId)
    requireOwner(pantry, OPENID)
    await pantries.doc(pantry._id).update({ data: { status: 'dissolved', revision: pantry.revision + 1, updatedAt: Date.now() } })
    return { ok: true }
  }

  throw new Error('不支持的共享食仓操作')
}
